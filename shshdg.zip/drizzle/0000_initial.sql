
CREATE TABLE IF NOT EXISTS "users" (
    "id" serial PRIMARY KEY,
    "username" text NOT NULL UNIQUE,
    "password" text NOT NULL,
    "is_admin" boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS "projects" (
    "id" serial PRIMARY KEY,
    "user_id" serial NOT NULL,
    "name" text NOT NULL,
    "status" text NOT NULL DEFAULT 'pending',
    "uploaded_at" timestamp NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "api_keys" (
    "id" serial PRIMARY KEY,
    "user_id" serial NOT NULL,
    "key" text NOT NULL,
    "created_at" timestamp NOT NULL DEFAULT now()
);
