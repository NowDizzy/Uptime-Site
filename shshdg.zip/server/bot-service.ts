import { spawn } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { Project } from "@shared/schema";

export class BotService {
  private static instance: BotService;
  private runningBots: Map<number, { process: any; pid: string }>;

  private constructor() {
    this.runningBots = new Map();
  }

  static getInstance(): BotService {
    if (!BotService.instance) {
      BotService.instance = new BotService();
    }
    return BotService.instance;
  }

  async startBot(project: Project): Promise<void> {
    try {
      if (!project.botToken) {
        throw new Error("Bot token gereklidir");
      }

      const projectDir = path.join("uploads", project.id.toString());
      if (!fs.existsSync(projectDir)) {
        throw new Error("Proje dizini bulunamadı");
      }

      const startFile = this.findStartFile(projectDir);
      if (!startFile) {
        throw new Error(
          "Başlangıç dosyası bulunamadı (start.bat, index.js, app.js veya bot.js gerekli)"
        );
      }

      // Önce npm install çalıştır
      try {
        await promisify(require('child_process').exec)('npm install', { cwd: projectDir });
      } catch (error) {
        console.error(`npm install error for bot ${project.id}:`, error);
        // npm install hatası olsa bile devam et
      }

      // Bot process'ini başlat
      let command = 'node';
      let args = [startFile];

      // Eğer start.bat varsa onu çalıştır
      if (startFile.toLowerCase().endsWith('.bat')) {
        command = startFile;
        args = [];
      }

      const botProcess = spawn(command, args, {
        cwd: projectDir,
        env: {
          ...process.env,
          BOT_TOKEN: project.botToken,
          NODE_ENV: 'production'
        }
      });

      // Process'i kaydet
      this.runningBots.set(project.id, {
        process: botProcess,
        pid: botProcess.pid?.toString() || ''
      });

      // Log çıktılarını dinle
      botProcess.stdout.on('data', (data) => {
        console.log(`Bot ${project.id} output:`, data.toString());
      });

      botProcess.stderr.on('data', (data) => {
        console.error(`Bot ${project.id} error:`, data.toString());
      });

      botProcess.on('exit', async (code) => {
        console.log(`Bot ${project.id} exited with code ${code}`);
        this.runningBots.delete(project.id);
        await storage.updateProjectIsRunning(project.id, false);
        await storage.updateProjectStatus(project.id, "stopped");
      });

      // Durumu güncelle
      await storage.updateProjectIsRunning(project.id, true);
      await storage.updateProjectStatus(project.id, "running");

    } catch (error) {
      console.error(`Error starting bot ${project.id}:`, error);
      await storage.updateProjectStatus(project.id, "error");
      await storage.updateProjectIsRunning(project.id, false);
      throw error;
    }
  }

  async stopBot(projectId: number): Promise<void> {
    const bot = this.runningBots.get(projectId);
    if (bot) {
      try {
        bot.process.kill();
        this.runningBots.delete(projectId);
        await storage.updateProjectStatus(projectId, "stopped");
        await storage.updateProjectIsRunning(projectId, false);
      } catch (error) {
        console.error(`Error stopping bot ${projectId}:`, error);
        throw error;
      }
    }
  }

  private findStartFile(projectDir: string): string | null {
    const potentialFiles = ["start.bat", "index.js", "app.js", "bot.js"];

    // Önce dizindeki tüm dosyaları al
    const files = fs.readdirSync(projectDir);

    // Büyük-küçük harf duyarsız karşılaştırma için dosya isimlerini küçük harfe çevir
    const lowerCaseFiles = files.map(f => f.toLowerCase());

    // Potansiyel dosyaları kontrol et
    for (const potentialFile of potentialFiles) {
      const lowerPotentialFile = potentialFile.toLowerCase();
      const index = lowerCaseFiles.findIndex(f => f === lowerPotentialFile);
      if (index !== -1) {
        // Orijinal dosya adını döndür
        return files[index];
      }
    }

    return null;
  }

  async restartBot(project: Project): Promise<void> {
    await this.stopBot(project.id);
    await this.startBot(project);
  }

  async startAllBots(): Promise<void> {
    const projects = await storage.getAllProjects();
    for (const project of projects) {
      if (project.botToken) {
        try {
          await this.startBot(project);
        } catch (error) {
          console.error(`Failed to start bot ${project.id}:`, error);
        }
      }
    }
  }
}

export const botService = BotService.getInstance();