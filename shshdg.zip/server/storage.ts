import { User, Project, ApiKey, InsertUser } from "@shared/schema";
import { users, projects, apiKeys } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { randomBytes } from "crypto";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getProjects(userId: number): Promise<Project[]>;
  getAllProjects(): Promise<Project[]>;
  createProject(userId: number, name: string): Promise<Project>;
  deleteProject(id: number, userId: number): Promise<void>;
  updateProjectStatus(id: number, status: string): Promise<void>;
  updateProjectIsRunning(id: number, isRunning: boolean): Promise<void>;
  updateProjectBotToken(id: number, token: string): Promise<void>;

  getApiKeys(userId: number): Promise<ApiKey[]>;
  createApiKey(userId: number): Promise<ApiKey>;

  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllProjects(): Promise<Project[]> {
    return db.select().from(projects);
  }

  async getProjects(userId: number): Promise<Project[]> {
    return db.select().from(projects).where(eq(projects.userId, userId));
  }

  async createProject(userId: number, name: string): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values({ userId, name })
      .returning();
    return project;
  }

  async deleteProject(id: number, userId: number): Promise<void> {
    await db
      .delete(projects)
      .where(eq(projects.id, id))
      .where(eq(projects.userId, userId));
  }

  async updateProjectStatus(id: number, status: string): Promise<void> {
    await db
      .update(projects)
      .set({ status })
      .where(eq(projects.id, id));
  }

  async updateProjectIsRunning(id: number, isRunning: boolean): Promise<void> {
    await db
      .update(projects)
      .set({ isRunning })
      .where(eq(projects.id, id));
  }

  async updateProjectBotToken(id: number, botToken: string): Promise<void> {
    await db
      .update(projects)
      .set({ botToken })
      .where(eq(projects.id, id));
  }

  async getApiKeys(userId: number): Promise<ApiKey[]> {
    return db.select().from(apiKeys).where(eq(apiKeys.userId, userId));
  }

  async createApiKey(userId: number): Promise<ApiKey> {
    const [apiKey] = await db
      .insert(apiKeys)
      .values({ 
        userId,
        key: randomBytes(32).toString('hex')
      })
      .returning();
    return apiKey;
  }
}

export const storage = new DatabaseStorage();