module.exports = {
    // Botu Kullanmadan README.md dosyasını okuyun!
    "Token": "MTMwNTA5Mjc3MDUzMjI5NDc2Ng.GP6Pxo.qGBWwAk2sQDSgNuvma8K4eAcnJkKw1zlfJLpIY"
    // Botu Kullanmadan README.md dosyasını okuyun!
}
