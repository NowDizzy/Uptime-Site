import { useQuery, useMutation } from "@tanstack/react-query";
import { ApiKey } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Key } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ApiKeyManagement() {
  const { toast } = useToast();
  
  const { data: keys, isLoading } = useQuery<ApiKey[]>({
    queryKey: ["/api/keys"],
  });

  const createKeyMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/keys");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/keys"] });
      toast({
        title: "Success",
        description: "API key generated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Your API Keys</h2>
        <Button
          onClick={() => createKeyMutation.mutate()}
          disabled={createKeyMutation.isPending}
        >
          {createKeyMutation.isPending && (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          )}
          Generate New Key
        </Button>
      </div>

      <div className="space-y-4">
        {!keys?.length ? (
          <div className="text-center p-8 text-muted-foreground">
            No API keys generated yet
          </div>
        ) : (
          keys.map((apiKey) => (
            <Card key={apiKey.id}>
              <CardContent className="flex items-center gap-4 py-4">
                <Key className="h-4 w-4 text-muted-foreground" />
                <div className="flex-1 font-mono text-sm">{apiKey.key}</div>
                <div className="text-xs text-muted-foreground">
                  Created: {new Date(apiKey.createdAt).toLocaleDateString()}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
